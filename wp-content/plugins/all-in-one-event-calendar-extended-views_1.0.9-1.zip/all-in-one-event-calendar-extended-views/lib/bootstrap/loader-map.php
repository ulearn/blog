<?php return array (
  '0registered' => 
  array (
    '' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'www' . DIRECTORY_SEPARATOR . 'wordpress_core' . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'all-in-one-event-calendar' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'bootstrap' . DIRECTORY_SEPARATOR . 'loader-map.php' => true,
  ),
  '1class_map' => 
  array (
    'Ai1ec_Calendar_View_Posterboard' => 
    array (
      'f' => AI1ECEV_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'view' . DIRECTORY_SEPARATOR . 'calendar' . DIRECTORY_SEPARATOR . 'view' . DIRECTORY_SEPARATOR . 'posterboard.php',
      'c' => 'Ai1ec_Calendar_View_Posterboard',
      'i' => 'g',
      'r' => 'y',
    ),
    'Ai1ec_Calendar_View_Stream' => 
    array (
      'f' => AI1ECEV_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'view' . DIRECTORY_SEPARATOR . 'calendar' . DIRECTORY_SEPARATOR . 'view' . DIRECTORY_SEPARATOR . 'stream.php',
      'c' => 'Ai1ec_Calendar_View_Stream',
      'i' => 'g',
      'r' => 'y',
    ),
    'Ai1ec_Controller_Ai1ecev' => 
    array (
      'f' => AI1ECEV_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'ai1ecev.php',
      'c' => 'Ai1ec_Controller_Ai1ecev',
      'i' => 'g',
    ),
    'Ai1ec_Javascript_Extended_Views' => 
    array (
      'f' => AI1ECEV_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'javascript' . DIRECTORY_SEPARATOR . 'extended_views.php',
      'c' => 'Ai1ec_Javascript_Extended_Views',
      'i' => 'g',
      'r' => 'y',
    ),
    'Ai1ec_Less_Extended_Views' => 
    array (
      'f' => AI1ECEV_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'less' . DIRECTORY_SEPARATOR . 'extended_views.php',
      'c' => 'Ai1ec_Less_Extended_Views',
      'i' => 'g',
      'r' => 'y',
    ),
    'EDD_SL_Plugin_Updater' => 
    array (
      'f' => AI1ECEV_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'edd' . DIRECTORY_SEPARATOR . 'EDD_SL_Plugin_Updater.php',
      'c' => 'EDD_SL_Plugin_Updater',
      'i' => 'g',
    ),
    'controller.ai1ecev' => 
    array (
      'f' => AI1ECEV_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'ai1ecev.php',
      'c' => 'Ai1ec_Controller_Ai1ecev',
      'i' => 'g',
    ),
    'edd.EDD_SL_Plugin_Updater' => 
    array (
      'f' => AI1ECEV_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'edd' . DIRECTORY_SEPARATOR . 'EDD_SL_Plugin_Updater.php',
      'c' => 'EDD_SL_Plugin_Updater',
      'i' => 'g',
    ),
    'javascript.extended_views' => 
    array (
      'f' => AI1ECEV_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'javascript' . DIRECTORY_SEPARATOR . 'extended_views.php',
      'c' => 'Ai1ec_Javascript_Extended_Views',
      'i' => 'g',
      'r' => 'y',
    ),
    'less.extended_views' => 
    array (
      'f' => AI1ECEV_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'less' . DIRECTORY_SEPARATOR . 'extended_views.php',
      'c' => 'Ai1ec_Less_Extended_Views',
      'i' => 'g',
      'r' => 'y',
    ),
    'view.calendar.view.posterboard' => 
    array (
      'f' => AI1ECEV_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'view' . DIRECTORY_SEPARATOR . 'calendar' . DIRECTORY_SEPARATOR . 'view' . DIRECTORY_SEPARATOR . 'posterboard.php',
      'c' => 'Ai1ec_Calendar_View_Posterboard',
      'i' => 'g',
      'r' => 'y',
    ),
    'view.calendar.view.stream' => 
    array (
      'f' => AI1ECEV_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'view' . DIRECTORY_SEPARATOR . 'calendar' . DIRECTORY_SEPARATOR . 'view' . DIRECTORY_SEPARATOR . 'stream.php',
      'c' => 'Ai1ec_Calendar_View_Stream',
      'i' => 'g',
      'r' => 'y',
    ),
  ),
);