<?php return array (
  '0registered' => 
  array (
    '' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'www' . DIRECTORY_SEPARATOR . 'wordpress_core' . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'all-in-one-event-calendar' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'bootstrap' . DIRECTORY_SEPARATOR . 'loader-map.php' => true,
    '' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'www' . DIRECTORY_SEPARATOR . 'wordpress_core' . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'all-in-one-event-calendar-extended-views' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'bootstrap' . DIRECTORY_SEPARATOR . 'loader-map.php' => true,
    '' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'www' . DIRECTORY_SEPARATOR . 'wordpress_core' . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'all-in-one-event-calendar-frontend-submissions' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'bootstrap' . DIRECTORY_SEPARATOR . 'loader-map.php' => true,
    '' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'www' . DIRECTORY_SEPARATOR . 'wordpress_core' . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'all-in-one-event-calendar-twitter-integration' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'bootstrap' . DIRECTORY_SEPARATOR . 'loader-map.php' => true,
    '' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'www' . DIRECTORY_SEPARATOR . 'wordpress_core' . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'all-in-one-event-calendar-csv-feed' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'bootstrap' . DIRECTORY_SEPARATOR . 'loader-map.php' => true,
    '' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'www' . DIRECTORY_SEPARATOR . 'wordpress_core' . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'all-in-one-event-calendar-facebook-integration' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'bootstrap' . DIRECTORY_SEPARATOR . 'loader-map.php' => true,
  ),
  '1class_map' => 
  array (
    'Ai1ec_Controller_Ai1ecsw' => 
    array (
      'f' => AI1ECSW_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'ai1ecsw.php',
      'c' => 'Ai1ec_Controller_Ai1ecsw',
      'i' => 'g',
    ),
    'Ai1ec_Html_Setting_Html_Sw' => 
    array (
      'f' => AI1ECSW_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'html' . DIRECTORY_SEPARATOR . 'element' . DIRECTORY_SEPARATOR . 'setting' . DIRECTORY_SEPARATOR . 'html-sw.php',
      'c' => 'Ai1ec_Html_Setting_Html_Sw',
      'i' => 'n',
      'r' => 'y',
    ),
    'Ai1ec_Javascript_Super_Widget' => 
    array (
      'f' => AI1ECSW_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'javascript' . DIRECTORY_SEPARATOR . 'super-widget.php',
      'c' => 'Ai1ec_Javascript_Super_Widget',
      'i' => 'g',
      'r' => 'y',
    ),
    'EDD_SL_Plugin_Updater' => 
    array (
      'f' => AI1ECSW_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'edd' . DIRECTORY_SEPARATOR . 'EDD_SL_Plugin_Updater.php',
      'c' => 'EDD_SL_Plugin_Updater',
      'i' => 'g',
    ),
    'controller.ai1ecsw' => 
    array (
      'f' => AI1ECSW_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'ai1ecsw.php',
      'c' => 'Ai1ec_Controller_Ai1ecsw',
      'i' => 'g',
    ),
    'edd.EDD_SL_Plugin_Updater' => 
    array (
      'f' => AI1ECSW_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'edd' . DIRECTORY_SEPARATOR . 'EDD_SL_Plugin_Updater.php',
      'c' => 'EDD_SL_Plugin_Updater',
      'i' => 'g',
    ),
    'html.element.setting.html-sw' => 
    array (
      'f' => AI1ECSW_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'html' . DIRECTORY_SEPARATOR . 'element' . DIRECTORY_SEPARATOR . 'setting' . DIRECTORY_SEPARATOR . 'html-sw.php',
      'c' => 'Ai1ec_Html_Setting_Html_Sw',
      'i' => 'n',
      'r' => 'y',
    ),
    'javascript.super-widget' => 
    array (
      'f' => AI1ECSW_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'javascript' . DIRECTORY_SEPARATOR . 'super-widget.php',
      'c' => 'Ai1ec_Javascript_Super_Widget',
      'i' => 'g',
      'r' => 'y',
    ),
  ),
);