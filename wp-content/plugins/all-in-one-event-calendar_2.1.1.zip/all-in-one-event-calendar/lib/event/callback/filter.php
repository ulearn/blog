<?php

/**
 * Event Callback Filter creation.
 *
 * @author     Time.ly Network Inc.
 * @since      2.0
 *
 * @instantiator new
 * @package      AI1EC
 * @subpackage   AI1EC.Event
 */
class Ai1ec_Event_Callback_Filter extends Ai1ec_Event_Callback_Abstract {
}