<div class="error">
	<?php foreach ( $msgs as $msg) : ?>
	<p>
		<strong>
			<?php echo $msg; ?>
		</strong>
	</p>
	<?php endforeach; ?>
</div>