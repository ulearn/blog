<?php

/**
 * Exception occuring during settings modification.
 *
 * @author     Time.ly Network, Inc.
 * @since      2.0
 * @package    Ai1EC
 * @subpackage Ai1EC.Html
 */
class Ai1ec_Settings_Exception extends Ai1ec_Exception {
}