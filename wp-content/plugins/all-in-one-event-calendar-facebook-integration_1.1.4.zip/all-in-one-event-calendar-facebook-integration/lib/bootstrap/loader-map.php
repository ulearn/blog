<?php return array (
  '0registered' => 
  array (
    '' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'www' . DIRECTORY_SEPARATOR . 'wordpress_core' . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'all-in-one-event-calendar' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'bootstrap' . DIRECTORY_SEPARATOR . 'loader-map.php' => true,
    '' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'www' . DIRECTORY_SEPARATOR . 'wordpress_core' . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'all-in-one-event-calendar-extended-views' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'bootstrap' . DIRECTORY_SEPARATOR . 'loader-map.php' => true,
    '' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'www' . DIRECTORY_SEPARATOR . 'wordpress_core' . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'all-in-one-event-calendar-frontend-submissions' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'bootstrap' . DIRECTORY_SEPARATOR . 'loader-map.php' => true,
    '' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'www' . DIRECTORY_SEPARATOR . 'wordpress_core' . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'all-in-one-event-calendar-twitter-integration' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'bootstrap' . DIRECTORY_SEPARATOR . 'loader-map.php' => true,
    '' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'www' . DIRECTORY_SEPARATOR . 'wordpress_core' . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'all-in-one-event-calendar-csv-feed' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'bootstrap' . DIRECTORY_SEPARATOR . 'loader-map.php' => true,
  ),
  '1class_map' => 
  array (
    'Ai1ecFacebookConnectorPlugin' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'calendar-feeds' . DIRECTORY_SEPARATOR . 'facebook.php',
      'c' => 'Ai1ecFacebookConnectorPlugin',
      'i' => 'g',
      'r' => 'y',
    ),
    'Ai1ec_Adapters_Factory' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-adapters-factory.php',
      'c' => 'Ai1ec_Adapters_Factory',
      'i' => 'g',
    ),
    'Ai1ec_Base_Container' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-base-container.php',
      'c' => 'Ai1ec_Base_Container',
      'i' => 'g',
    ),
    'Ai1ec_Blank_Html_Element' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'class-ai1ec-blank-html-element.php',
      'c' => 'Ai1ec_Blank_Html_Element',
      'i' => 'g',
    ),
    'Ai1ec_Bootstrap_Radio' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'bootstrap_helpers' . DIRECTORY_SEPARATOR . 'class-ai1ec-bootstrap-radio.php',
      'c' => 'Ai1ec_Bootstrap_Radio',
      'i' => 'g',
    ),
    'Ai1ec_Container' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-container.php',
      'c' => 'Ai1ec_Container',
      'i' => 'g',
    ),
    'Ai1ec_Controller_Ai1ecfi' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'ai1ecfi.php',
      'c' => 'Ai1ec_Controller_Ai1ecfi',
      'i' => 'g',
    ),
    'Ai1ec_Date_Time_Zone_Utility' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'time' . DIRECTORY_SEPARATOR . 'class-ai1ec-date-time-zone-utility.php',
      'c' => 'Ai1ec_Date_Time_Zone_Utility',
      'i' => 'g',
    ),
    'Ai1ec_Error_Validating_App_Id_And_Secret' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-error-validating-app-id-and-secret.php',
      'c' => 'Ai1ec_Error_Validating_App_Id_And_Secret',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Application' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-application.php',
      'c' => 'Ai1ec_Facebook_Application',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Current_User' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-current-user.php',
      'c' => 'Ai1ec_Facebook_Current_User',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Custom_Bulk_Action' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-custom-bulk-action.php',
      'c' => 'Ai1ec_Facebook_Custom_Bulk_Action',
      'i' => 'g',
      'r' => 'y',
    ),
    'Ai1ec_Facebook_Data_Converter' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-data-converter.php',
      'c' => 'Ai1ec_Facebook_Data_Converter',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Db_Exception' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-db-exception.php',
      'c' => 'Ai1ec_Facebook_Db_Exception',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Event' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-event.php',
      'c' => 'Ai1ec_Facebook_Event',
      'i' => 'g',
      'r' => 'y',
    ),
    'Ai1ec_Facebook_Factory' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-factory.php',
      'c' => 'Ai1ec_Facebook_Factory',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Friends_Sync_Exception' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-friends-sync-exception.php',
      'c' => 'Ai1ec_Facebook_Friends_Sync_Exception',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Graph_Object' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-graph-object.php',
      'c' => 'Ai1ec_Facebook_Graph_Object',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Graph_Object_Collection' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-graph-object-collection.php',
      'c' => 'Ai1ec_Facebook_Graph_Object_Collection',
      'i' => 'g',
      'r' => 'y',
    ),
    'Ai1ec_Facebook_Group_Query_Events_Strategy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-group-query-events-strategy.php',
      'c' => 'Ai1ec_Facebook_Group_Query_Events_Strategy',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Group_Sync_Object_From_Facebook_Strategy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-group-sync-object-from-facebook-strategy.php',
      'c' => 'Ai1ec_Facebook_Group_Sync_Object_From_Facebook_Strategy',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Meta' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'meta.php',
      'c' => 'Ai1ec_Facebook_Meta',
      'i' => 'g',
      'r' => 'y',
    ),
    'Ai1ec_Facebook_Page_Sync_Object_From_Facebook_Strategy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-page-sync-object-from-facebook-strategy.php',
      'c' => 'Ai1ec_Facebook_Page_Sync_Object_From_Facebook_Strategy',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Proxy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'proxy.php',
      'c' => 'Ai1ec_Facebook_Proxy',
      'i' => 'g',
      'r' => 'y',
    ),
    'Ai1ec_Facebook_Query_Abstract' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-query-abstract.php',
      'c' => 'Ai1ec_Facebook_Query_Abstract',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Sync_Object_Abstract' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-sync-object-abstract.php',
      'c' => 'Ai1ec_Facebook_Sync_Object_Abstract',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_Tab' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-tab.php',
      'c' => 'Ai1ec_Facebook_Tab',
      'i' => 'g',
      'r' => 'y',
    ),
    'Ai1ec_Facebook_User' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'facebook-user.php',
      'c' => 'Ai1ec_Facebook_User',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_User_Query_Events_Strategy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-user-query-events-strategy.php',
      'c' => 'Ai1ec_Facebook_User_Query_Events_Strategy',
      'i' => 'g',
    ),
    'Ai1ec_Facebook_User_Sync_Object_From_Facebook_Strategy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-user-sync-object-from-facebook-strategy.php',
      'c' => 'Ai1ec_Facebook_User_Sync_Object_From_Facebook_Strategy',
      'i' => 'g',
    ),
    'Ai1ec_Generic_Html_Tag' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'class-ai1ec-generic-html-tag.php',
      'c' => 'Ai1ec_Generic_Html_Tag',
      'i' => 'g',
    ),
    'Ai1ec_Helper_Factory' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-helper-factory.php',
      'c' => 'Ai1ec_Helper_Factory',
      'i' => 'g',
    ),
    'Ai1ec_Html_Element_Can_Have_Children' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-html-element-can-have-children.php',
      'c' => 'Ai1ec_Html_Element_Can_Have_Children',
      'i' => 'g',
    ),
    'Ai1ec_Html_Element_Legacy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-html-element.php',
      'c' => 'Ai1ec_Html_Element_Legacy',
      'i' => 'g',
    ),
    'Ai1ec_Input' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'class-ai1ec-input.php',
      'c' => 'Ai1ec_Input',
      'i' => 'g',
    ),
    'Ai1ec_Invalid_Argument' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'invalid-argument.php',
      'c' => 'Ai1ec_Invalid_Argument',
      'i' => 'g',
    ),
    'Ai1ec_Javascript_Facebook' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'javascript' . DIRECTORY_SEPARATOR . 'facebook.php',
      'c' => 'Ai1ec_Javascript_Facebook',
      'i' => 'g',
      'r' => 'y',
    ),
    'Ai1ec_Memory_Utility' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'time' . DIRECTORY_SEPARATOR . 'class-ai1ec-memory-utility.php',
      'c' => 'Ai1ec_Memory_Utility',
      'i' => 'g',
    ),
    'Ai1ec_No_Valid_Facebook_Access_Token' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-no-valid-facebook-access-token.php',
      'c' => 'Ai1ec_No_Valid_Facebook_Access_Token',
      'i' => 'g',
    ),
    'Ai1ec_Select' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'class-ai1ec-select.php',
      'c' => 'Ai1ec_Select',
      'i' => 'g',
    ),
    'Ai1ec_Template_Adapter' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'adapter' . DIRECTORY_SEPARATOR . 'class-ai1ec-template-adapter.php',
      'c' => 'Ai1ec_Template_Adapter',
      'i' => 'g',
    ),
    'Ai1ec_Time_I18n_Utility_Legacy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'time' . DIRECTORY_SEPARATOR . 'class-ai1ec-time-i18n-utility.php',
      'c' => 'Ai1ec_Time_I18n_Utility_Legacy',
      'i' => 'g',
    ),
    'Ai1ec_Time_Utility_Legacy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'time' . DIRECTORY_SEPARATOR . 'class-ai1ec-time-utility.php',
      'c' => 'Ai1ec_Time_Utility_Legacy',
      'i' => 'g',
    ),
    'Ai1ec_Wordpress_Template_Adapter' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'adapter' . DIRECTORY_SEPARATOR . 'class-ai1ec-wordpress-template-adapter.php',
      'c' => 'Ai1ec_Wordpress_Template_Adapter',
      'i' => 'g',
    ),
    'Facebook_WP_Extend_Ai1ec' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'class-facebook-wp.php',
      'c' => 'Facebook_WP_Extend_Ai1ec',
      'i' => 'g',
    ),
    'Query_Events_Strategy_Interface' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-query-events-strategy-interface.php',
      'c' => 'Query_Events_Strategy_Interface',
      'i' => 'g',
    ),
    'Sync_Objects_From_Facebook_Strategy_Interface' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-sync-objects-from-facebook-strategy-interface.php',
      'c' => 'Sync_Objects_From_Facebook_Strategy_Interface',
      'i' => 'g',
    ),
    'WP_BaseFacebook_Ai1ec' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'base_facebook.php',
      'c' => 'WP_BaseFacebook_Ai1ec',
      'i' => 'g',
    ),
    'WP_FacebookApiException' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'base_facebook.php',
      'c' => 'WP_FacebookApiException',
      'i' => 'g',
    ),
    'WP_Facebook_Ai1ec' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'facebook.php',
      'c' => 'WP_Facebook_Ai1ec',
      'i' => 'g',
    ),
    'calendar-feeds.facebook' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'calendar-feeds' . DIRECTORY_SEPARATOR . 'facebook.php',
      'c' => 'Ai1ecFacebookConnectorPlugin',
      'i' => 'g',
      'r' => 'y',
    ),
    'controller.ai1ecfi' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'ai1ecfi.php',
      'c' => 'Ai1ec_Controller_Ai1ecfi',
      'i' => 'g',
    ),
    'facebook-php-sdk.base_facebook' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'base_facebook.php',
      'c' => 'WP_BaseFacebook_Ai1ec',
      'i' => 'g',
    ),
    'facebook-php-sdk.class-facebook-wp' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'class-facebook-wp.php',
      'c' => 'Facebook_WP_Extend_Ai1ec',
      'i' => 'g',
    ),
    'facebook-php-sdk.facebook' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'facebook.php',
      'c' => 'WP_Facebook_Ai1ec',
      'i' => 'g',
    ),
    'facebook-php-sdk.facebook-user' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'facebook-user.php',
      'c' => 'Ai1ec_Facebook_User',
      'i' => 'g',
    ),
    'facebook.meta' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'meta.php',
      'c' => 'Ai1ec_Facebook_Meta',
      'i' => 'g',
      'r' => 'y',
    ),
    'facebook.proxy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'proxy.php',
      'c' => 'Ai1ec_Facebook_Proxy',
      'i' => 'g',
      'r' => 'y',
    ),
    'javascript.facebook' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'javascript' . DIRECTORY_SEPARATOR . 'facebook.php',
      'c' => 'Ai1ec_Javascript_Facebook',
      'i' => 'g',
      'r' => 'y',
    ),
    'legacy.adapter.class-ai1ec-template-adapter' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'adapter' . DIRECTORY_SEPARATOR . 'class-ai1ec-template-adapter.php',
      'c' => 'Ai1ec_Template_Adapter',
      'i' => 'g',
    ),
    'legacy.adapter.class-ai1ec-wordpress-template-adapter' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'adapter' . DIRECTORY_SEPARATOR . 'class-ai1ec-wordpress-template-adapter.php',
      'c' => 'Ai1ec_Wordpress_Template_Adapter',
      'i' => 'g',
    ),
    'legacy.bootstrap_helpers.class-ai1ec-bootstrap-radio' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'bootstrap_helpers' . DIRECTORY_SEPARATOR . 'class-ai1ec-bootstrap-radio.php',
      'c' => 'Ai1ec_Bootstrap_Radio',
      'i' => 'g',
    ),
    'legacy.exception.class-ai1ec-error-validating-app-id-and-secret' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-error-validating-app-id-and-secret.php',
      'c' => 'Ai1ec_Error_Validating_App_Id_And_Secret',
      'i' => 'g',
    ),
    'legacy.exception.class-ai1ec-facebook-db-exception' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-db-exception.php',
      'c' => 'Ai1ec_Facebook_Db_Exception',
      'i' => 'g',
    ),
    'legacy.exception.class-ai1ec-facebook-friends-sync-exception' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-friends-sync-exception.php',
      'c' => 'Ai1ec_Facebook_Friends_Sync_Exception',
      'i' => 'g',
    ),
    'legacy.exception.class-ai1ec-no-valid-facebook-access-token' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-no-valid-facebook-access-token.php',
      'c' => 'Ai1ec_No_Valid_Facebook_Access_Token',
      'i' => 'g',
    ),
    'legacy.exception.invalid-argument' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'invalid-argument.php',
      'c' => 'Ai1ec_Invalid_Argument',
      'i' => 'g',
    ),
    'legacy.facebook.class-ai1ec-facebook-application' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-application.php',
      'c' => 'Ai1ec_Facebook_Application',
      'i' => 'g',
    ),
    'legacy.facebook.class-ai1ec-facebook-current-user' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-current-user.php',
      'c' => 'Ai1ec_Facebook_Current_User',
      'i' => 'g',
    ),
    'legacy.facebook.class-ai1ec-facebook-custom-bulk-action' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-custom-bulk-action.php',
      'c' => 'Ai1ec_Facebook_Custom_Bulk_Action',
      'i' => 'g',
      'r' => 'y',
    ),
    'legacy.facebook.class-ai1ec-facebook-data-converter' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-data-converter.php',
      'c' => 'Ai1ec_Facebook_Data_Converter',
      'i' => 'g',
    ),
    'legacy.facebook.class-ai1ec-facebook-event' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-event.php',
      'c' => 'Ai1ec_Facebook_Event',
      'i' => 'g',
      'r' => 'y',
    ),
    'legacy.facebook.class-ai1ec-facebook-graph-object' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-graph-object.php',
      'c' => 'Ai1ec_Facebook_Graph_Object',
      'i' => 'g',
    ),
    'legacy.facebook.class-ai1ec-facebook-graph-object-collection' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-graph-object-collection.php',
      'c' => 'Ai1ec_Facebook_Graph_Object_Collection',
      'i' => 'g',
      'r' => 'y',
    ),
    'legacy.facebook.class-ai1ec-facebook-group-query-events-strategy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-group-query-events-strategy.php',
      'c' => 'Ai1ec_Facebook_Group_Query_Events_Strategy',
      'i' => 'g',
    ),
    'legacy.facebook.class-ai1ec-facebook-group-sync-object-from-facebook-strategy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-group-sync-object-from-facebook-strategy.php',
      'c' => 'Ai1ec_Facebook_Group_Sync_Object_From_Facebook_Strategy',
      'i' => 'g',
    ),
    'legacy.facebook.class-ai1ec-facebook-page-sync-object-from-facebook-strategy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-page-sync-object-from-facebook-strategy.php',
      'c' => 'Ai1ec_Facebook_Page_Sync_Object_From_Facebook_Strategy',
      'i' => 'g',
    ),
    'legacy.facebook.class-ai1ec-facebook-query-abstract' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-query-abstract.php',
      'c' => 'Ai1ec_Facebook_Query_Abstract',
      'i' => 'g',
    ),
    'legacy.facebook.class-ai1ec-facebook-sync-object-abstract' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-sync-object-abstract.php',
      'c' => 'Ai1ec_Facebook_Sync_Object_Abstract',
      'i' => 'g',
    ),
    'legacy.facebook.class-ai1ec-facebook-tab' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-tab.php',
      'c' => 'Ai1ec_Facebook_Tab',
      'i' => 'g',
      'r' => 'y',
    ),
    'legacy.facebook.class-ai1ec-facebook-user-query-events-strategy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-user-query-events-strategy.php',
      'c' => 'Ai1ec_Facebook_User_Query_Events_Strategy',
      'i' => 'g',
    ),
    'legacy.facebook.class-ai1ec-facebook-user-sync-object-from-facebook-strategy' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-user-sync-object-from-facebook-strategy.php',
      'c' => 'Ai1ec_Facebook_User_Sync_Object_From_Facebook_Strategy',
      'i' => 'g',
    ),
    'legacy.facebook.interface.class-query-events-strategy-interface' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-query-events-strategy-interface.php',
      'c' => 'Query_Events_Strategy_Interface',
      'i' => 'g',
    ),
    'legacy.facebook.interface.class-sync-objects-from-facebook-strategy-interface' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-sync-objects-from-facebook-strategy-interface.php',
      'c' => 'Sync_Objects_From_Facebook_Strategy_Interface',
      'i' => 'g',
    ),
    'legacy.factory.class-ai1ec-adapters-factory' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-adapters-factory.php',
      'c' => 'Ai1ec_Adapters_Factory',
      'i' => 'g',
    ),
    'legacy.factory.class-ai1ec-facebook-factory' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-factory.php',
      'c' => 'Ai1ec_Facebook_Factory',
      'i' => 'g',
    ),
    'legacy.factory.class-ai1ec-helper-factory' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-helper-factory.php',
      'c' => 'Ai1ec_Helper_Factory',
      'i' => 'g',
    ),
    'legacy.html_elements.abstract.class-ai1ec-base-container' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-base-container.php',
      'c' => 'Ai1ec_Base_Container',
      'i' => 'g',
    ),
    'legacy.html_elements.abstract.class-ai1ec-container' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-container.php',
      'c' => 'Ai1ec_Container',
      'i' => 'g',
    ),
    'legacy.html_elements.abstract.class-ai1ec-html-element' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-html-element.php',
      'c' => 'Ai1ec_Html_Element_Legacy',
      'i' => 'g',
    ),
    'legacy.html_elements.abstract.class-ai1ec-html-element-can-have-children' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-html-element-can-have-children.php',
      'c' => 'Ai1ec_Html_Element_Can_Have_Children',
      'i' => 'g',
    ),
    'legacy.html_elements.class-ai1ec-blank-html-element' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'class-ai1ec-blank-html-element.php',
      'c' => 'Ai1ec_Blank_Html_Element',
      'i' => 'g',
    ),
    'legacy.html_elements.class-ai1ec-generic-html-tag' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'class-ai1ec-generic-html-tag.php',
      'c' => 'Ai1ec_Generic_Html_Tag',
      'i' => 'g',
    ),
    'legacy.html_elements.class-ai1ec-input' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'class-ai1ec-input.php',
      'c' => 'Ai1ec_Input',
      'i' => 'g',
    ),
    'legacy.html_elements.class-ai1ec-select' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'class-ai1ec-select.php',
      'c' => 'Ai1ec_Select',
      'i' => 'g',
    ),
    'legacy.time.class-ai1ec-date-time-zone-utility' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'time' . DIRECTORY_SEPARATOR . 'class-ai1ec-date-time-zone-utility.php',
      'c' => 'Ai1ec_Date_Time_Zone_Utility',
      'i' => 'g',
    ),
    'legacy.time.class-ai1ec-memory-utility' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'time' . DIRECTORY_SEPARATOR . 'class-ai1ec-memory-utility.php',
      'c' => 'Ai1ec_Memory_Utility',
      'i' => 'g',
    ),
    'legacy.time.class-ai1ec-time-i18n-utility' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'time' . DIRECTORY_SEPARATOR . 'class-ai1ec-time-i18n-utility.php',
      'c' => 'Ai1ec_Time_I18n_Utility_Legacy',
      'i' => 'g',
    ),
    'legacy.time.class-ai1ec-time-utility' => 
    array (
      'f' => AI1ECFI_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'legacy' . DIRECTORY_SEPARATOR . 'time' . DIRECTORY_SEPARATOR . 'class-ai1ec-time-utility.php',
      'c' => 'Ai1ec_Time_Utility_Legacy',
      'i' => 'g',
    ),
  ),
);