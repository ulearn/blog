<?php
/**
 * 
 * 
 * 
 * @author The Seed Studio
 *
 */

interface Sync_Objects_From_Facebook_Strategy_Interface {
	
	public function get_users_from_facebook( Ai1ec_Facebook_Proxy $facebook );
	
}

?>